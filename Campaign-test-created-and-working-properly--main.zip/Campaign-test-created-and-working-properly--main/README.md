# Campaign-test-created-and-working-properly-
Currie’s Defense is a custom AI-assisted phishing email detection and cybersecurity awareness project designed to identify and explain common phishing indicators.
Currie’s Defense is a custom AI-assisted phishing email detection and cybersecurity awareness project designed to identify and explain common phishing indicators. As part of the initial testing phase, I configured GoPhish in a controlled lab environment and created a simulated Microsoft 365 security verification phishing campaign using my own Gmail account as the test recipient. I configured an SMTP sending profile, created a simulated phishing email containing urgent security language and a verification link, created a safe landing page that did not collect passwords or personal credentials, and created a test recipient group containing only my own account. After launching the campaign, I verified that the simulated email was delivered, the tracking link worked, and the landing page displayed the Currie’s Defense security analysis. The test identified several phishing indicators, including urgent security language, an account verification request, Microsoft 365 impersonation, a suspicious link, and a request for immediate action, resulting in a HIGH RISK classification. This testing environment provides the foundation for developing Currie’s Defense into a custom phishing detection tool that can analyze email characteristics, identify suspicious behavior, explain why an email is considered risky, and provide a risk classification of Legitimate, Suspicious, or High Risk. The project is being developed as a cybersecurity portfolio project with the goal of demonstrating practical experience in phishing analysis, security awareness testing, email security, risk classification, and defensive cybersecurity techniques.
Email that was sent for campaign testing purpose 
URGENT: Microsoft 365 Security Verification Required
Inbox

gleshaycurrie@gmail.com
10:21 AM (9 minutes ago)
to me

Hello Gleshay, This is a simulated cybersecurity awareness test from Currie's Defense. Your Microsoft 365 account has been flagged for a security verification review. Please review your account using the security verification link below: http://127.0.0.1?rid=R3ul7dh If you did not request this verification, please contact your IT department. Thank you, Currie's Defense Security Team


Link was provided and I was sent to the landed page that stated the response below 
Currie's Defense
Cybersecurity Phishing Simulation
This was a controlled Currie's Defense phishing simulation.

No password or personal credentials were collected.

Phishing Indicators Detected
Urgent security language
Account verification request
Microsoft 365 impersonation
Suspicious link
Request for immediate action
Risk Classification: HIGH RISK
Do not click suspicious links or provide credentials. Verify unexpected security requests through your organization's official IT support process.
